"""Runtime configuration.

All paths and tunables live here so the rest of the code stays clean.
Override anything via environment variables (12-factor style).
"""

from __future__ import annotations

import os
from pathlib import Path

# --- Paths --------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
FRONTEND_DIR = ROOT  # index.html + market-data.js sit at repo root
DB_PATH = Path(os.environ.get("PROCUREMIND_DB", ROOT / "should_cost.db"))
MODEL_DIR = Path(os.environ.get("PROCUREMIND_MODEL_DIR", ROOT / "models_cache"))
MARKET_DATA_FILE = ROOT / "market-data.js"

# --- Server -------------------------------------------------------------
HOST = os.environ.get("PROCUREMIND_HOST", "127.0.0.1")
PORT = int(os.environ.get("PROCUREMIND_PORT", "8000"))

# --- Engine tunables ----------------------------------------------------
# Minimum historical PO rows before we even try to fit an ML model.
ML_MIN_ROWS = int(os.environ.get("PROCUREMIND_ML_MIN_ROWS", "20"))
# Above this, ML is the headline number with rule-based as the explainer.
ML_FULL_TRUST_ROWS = int(os.environ.get("PROCUREMIND_ML_FULL_TRUST_ROWS", "100"))
# Percentile used to define the "fair price" benchmark band.
BAND_LOW_PCT = float(os.environ.get("PROCUREMIND_BAND_LOW_PCT", "0.25"))
BAND_HIGH_PCT = float(os.environ.get("PROCUREMIND_BAND_HIGH_PCT", "0.75"))

# --- Currency defaults --------------------------------------------------
DEFAULT_CURRENCY = os.environ.get("PROCUREMIND_CURRENCY", "USD")

# --- File upload limits -------------------------------------------------
MAX_UPLOAD_MB = int(os.environ.get("PROCUREMIND_MAX_UPLOAD_MB", "25"))

DATA_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)
