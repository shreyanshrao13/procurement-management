"""ORM models — the on-disk shape of every uploaded artifact.

Design notes
------------
* A **Category** is the unit of analysis. Everything else hangs off it.
* **BomItem** = one material line in a category's bill of materials.
* **MaterialPrice** = a price observation (user-uploaded or synced from
  ``market-data.js``). The latest row per material wins.
* **PurchaseOrder** = a historical PO line. Used to train the ML model
  and to compute historical averages.
* **SupplierQuote** = a current quote you're negotiating.
* **ShouldCostRun** = an audit-friendly snapshot of every estimate the
  engine produced (inputs + outputs + which method was used).

Dropping any one of these is harmless — the engine degrades gracefully
when an input is missing (e.g. no BOM → falls back to mix percentages).
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Float,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Category(Base):
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    family: Mapped[str] = mapped_column(String(64), default="custom")
    unit: Mapped[str] = mapped_column(String(64), default="per unit")
    region: Mapped[str] = mapped_column(String(32), default="GLOBAL")
    currency: Mapped[str] = mapped_column(String(8), default="USD")

    # Default cost-mix percentages (sum to 1). Used as a fallback when
    # there isn't enough granular input to build bottom-up.
    mix_materials: Mapped[float] = mapped_column(Float, default=0.45)
    mix_labor: Mapped[float] = mapped_column(Float, default=0.25)
    mix_overhead: Mapped[float] = mapped_column(Float, default=0.15)
    mix_margin: Mapped[float] = mapped_column(Float, default=0.15)

    # Optional anchors / assumptions
    overhead_rate: Mapped[float] = mapped_column(Float, default=0.18)  # % of direct
    target_margin: Mapped[float] = mapped_column(Float, default=0.12)  # % markup
    freight_pct: Mapped[float] = mapped_column(Float, default=0.05)
    notes: Mapped[str] = mapped_column(String(2000), default="")

    # Comma-separated market-index ids this category is exposed to (e.g. "steel_hrc,copper")
    market_links: Mapped[str] = mapped_column(String(500), default="")

    created_at: Mapped[datetime] = mapped_column(default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(default=_utcnow, onupdate=_utcnow)

    bom_items: Mapped[list["BomItem"]] = relationship(
        back_populates="category", cascade="all, delete-orphan"
    )
    labor_inputs: Mapped[list["LaborInput"]] = relationship(
        back_populates="category", cascade="all, delete-orphan"
    )
    quotes: Mapped[list["SupplierQuote"]] = relationship(
        back_populates="category", cascade="all, delete-orphan"
    )
    purchase_orders: Mapped[list["PurchaseOrder"]] = relationship(
        back_populates="category", cascade="all, delete-orphan"
    )
    runs: Mapped[list["ShouldCostRun"]] = relationship(
        back_populates="category", cascade="all, delete-orphan"
    )


class BomItem(Base):
    __tablename__ = "bom_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="CASCADE"))
    material: Mapped[str] = mapped_column(String(120), index=True)
    qty_per_unit: Mapped[float] = mapped_column(Float)
    uom: Mapped[str] = mapped_column(String(32), default="kg")
    yield_pct: Mapped[float] = mapped_column(Float, default=1.0)  # 1.0 = no scrap
    market_index: Mapped[str] = mapped_column(String(64), default="")  # link to market-data.js id

    category: Mapped[Category] = relationship(back_populates="bom_items")


class LaborInput(Base):
    __tablename__ = "labor_inputs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="CASCADE"))
    operation: Mapped[str] = mapped_column(String(120), default="primary")
    hours_per_unit: Mapped[float] = mapped_column(Float)
    rate_per_hour: Mapped[float] = mapped_column(Float)
    region: Mapped[str] = mapped_column(String(32), default="GLOBAL")

    category: Mapped[Category] = relationship(back_populates="labor_inputs")


class MaterialPrice(Base):
    """A unit price observation for a material.

    Source can be a user upload, a manual entry, or a sync from
    market-data.js. The most recent row per material is what the engine
    uses for new should-cost runs.
    """
    __tablename__ = "material_prices"
    __table_args__ = (UniqueConstraint("material", "as_of", "source", name="uq_mat_date_src"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    material: Mapped[str] = mapped_column(String(120), index=True)
    price: Mapped[float] = mapped_column(Float)
    uom: Mapped[str] = mapped_column(String(32), default="kg")
    currency: Mapped[str] = mapped_column(String(8), default="USD")
    as_of: Mapped[datetime] = mapped_column(default=_utcnow, index=True)
    source: Mapped[str] = mapped_column(String(64), default="user")  # user | market | quote


class PurchaseOrder(Base):
    """One historical PO line — what's actually used for ML training."""
    __tablename__ = "purchase_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="CASCADE"))
    supplier: Mapped[str] = mapped_column(String(120), default="")
    po_date: Mapped[datetime] = mapped_column(default=_utcnow, index=True)
    quantity: Mapped[float] = mapped_column(Float)
    unit_price: Mapped[float] = mapped_column(Float)
    region: Mapped[str] = mapped_column(String(32), default="GLOBAL")
    currency: Mapped[str] = mapped_column(String(8), default="USD")
    # Free-form spec attributes the ML model can use as features.
    spec: Mapped[dict] = mapped_column(JSON, default=dict)

    category: Mapped[Category] = relationship(back_populates="purchase_orders")


class SupplierQuote(Base):
    __tablename__ = "supplier_quotes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="CASCADE"))
    supplier: Mapped[str] = mapped_column(String(120))
    quoted_unit_price: Mapped[float] = mapped_column(Float)
    quantity: Mapped[float] = mapped_column(Float, default=1.0)
    currency: Mapped[str] = mapped_column(String(8), default="USD")
    valid_until: Mapped[datetime | None] = mapped_column(nullable=True)
    received_at: Mapped[datetime] = mapped_column(default=_utcnow)
    notes: Mapped[str] = mapped_column(String(1000), default="")

    category: Mapped[Category] = relationship(back_populates="quotes")


class ShouldCostRun(Base):
    """Audit log of every estimate the engine produced."""
    __tablename__ = "should_cost_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="CASCADE"))
    created_at: Mapped[datetime] = mapped_column(default=_utcnow, index=True)
    method: Mapped[str] = mapped_column(String(32))   # rule | ml | hybrid
    quantity: Mapped[float] = mapped_column(Float)
    region: Mapped[str] = mapped_column(String(32), default="GLOBAL")
    inputs: Mapped[dict] = mapped_column(JSON, default=dict)
    outputs: Mapped[dict] = mapped_column(JSON, default=dict)

    category: Mapped[Category] = relationship(back_populates="runs")
