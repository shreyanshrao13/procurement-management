"""Pydantic schemas for API request / response shapes.

Kept separate from ORM models on purpose — the API contract should be
free to evolve without dragging the database along (and vice versa).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


# ---------- Categories ----------
class CategoryIn(BaseModel):
    code: str
    name: str
    family: str = "custom"
    unit: str = "per unit"
    region: str = "GLOBAL"
    currency: str = "USD"
    mix_materials: float = 0.45
    mix_labor: float = 0.25
    mix_overhead: float = 0.15
    mix_margin: float = 0.15
    overhead_rate: float = 0.18
    target_margin: float = 0.12
    freight_pct: float = 0.05
    notes: str = ""
    market_links: str = ""


class CategoryOut(CategoryIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
    updated_at: datetime
    n_bom_items: int = 0
    n_pos: int = 0
    n_quotes: int = 0


class CategorySummary(BaseModel):
    """Lightweight category card for list views."""
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    name: str
    family: str
    unit: str
    region: str
    currency: str
    n_bom_items: int = 0
    n_pos: int = 0
    n_quotes: int = 0


# ---------- BOM / Labor ----------
class BomItemIn(BaseModel):
    material: str
    qty_per_unit: float
    uom: str = "kg"
    yield_pct: float = 1.0
    market_index: str = ""


class BomItemOut(BomItemIn):
    model_config = ConfigDict(from_attributes=True)
    id: int


class LaborInputIn(BaseModel):
    operation: str = "primary"
    hours_per_unit: float
    rate_per_hour: float
    region: str = "GLOBAL"


class LaborInputOut(LaborInputIn):
    model_config = ConfigDict(from_attributes=True)
    id: int


# ---------- Materials / POs / Quotes ----------
class MaterialPriceIn(BaseModel):
    material: str
    price: float
    uom: str = "kg"
    currency: str = "USD"
    as_of: datetime | None = None
    source: str = "user"


class PurchaseOrderIn(BaseModel):
    supplier: str = ""
    po_date: datetime | None = None
    quantity: float
    unit_price: float
    region: str = "GLOBAL"
    currency: str = "USD"
    spec: dict[str, Any] = Field(default_factory=dict)


class SupplierQuoteIn(BaseModel):
    supplier: str
    quoted_unit_price: float
    quantity: float = 1.0
    currency: str = "USD"
    valid_until: datetime | None = None
    notes: str = ""


# ---------- Should-Cost engine ----------
class EstimateRequest(BaseModel):
    category_id: int
    quantity: float = 1.0
    region: str | None = None
    quote: float | None = None
    # Optional scenario shifts on linked market indices, e.g. {"steel_hrc": 5.0} = +5%.
    market_scenario: dict[str, float] = Field(default_factory=dict)
    method: Literal["auto", "rule", "ml", "hybrid"] = "auto"


class CostBreakdown(BaseModel):
    materials: float
    labor: float
    overhead: float
    freight: float
    margin: float
    total: float


class EstimateResponse(BaseModel):
    category_id: int
    quantity: float
    method_used: Literal["rule", "ml", "hybrid"]
    rule_unit_cost: float
    ml_unit_cost: float | None
    ml_confidence: float | None
    hybrid_unit_cost: float
    breakdown: CostBreakdown
    historical_avg: float | None
    market_reference: float | None
    market_multiplier: float
    explanations: list[str]
    drivers: list[dict[str, Any]]
    band_low: float
    band_high: float


# ---------- Benchmark / Brief ----------
class BenchmarkRow(BaseModel):
    label: str
    unit_price: float
    annual: float
    delta_pct: float | None
    color: str


class NegotiationBrief(BaseModel):
    category: str
    family: str
    quantity: float
    unit: str
    currency: str
    target_price: float
    aggressive_anchor: float
    walk_away: float
    quote: float | None
    annual_savings: float
    savings_pct: float
    leverage_points: list[str]
    market_context: list[str]
    concessions: list[str]
    breakdown: CostBreakdown
    explanations: list[str]
    generated_at: datetime


# ---------- Upload responses ----------
class UploadResult(BaseModel):
    filename: str
    rows_read: int
    rows_inserted: int
    categories_touched: int
    warnings: list[str] = []
