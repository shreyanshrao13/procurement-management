"""Database session and engine wiring (SQLAlchemy 2.x + SQLite).

SQLite is the default because it's zero-config and ships with Python.
For multi-tenant / heavy concurrent writes, set ``PROCUREMIND_DB`` to a
PostgreSQL URL like ``postgresql+psycopg://user:pass@host/db`` and
nothing else changes.
"""

from __future__ import annotations

from collections.abc import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from . import config


def _make_url() -> str:
    p = str(config.DB_PATH)
    if p.startswith(("sqlite://", "postgresql://", "postgresql+")):
        return p
    return f"sqlite:///{p}"


engine = create_engine(
    _make_url(),
    future=True,
    # SQLite + multi-thread (uvicorn workers) needs check_same_thread off.
    connect_args={"check_same_thread": False} if "sqlite" in _make_url() else {},
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


class Base(DeclarativeBase):
    """Single declarative base shared by every ORM model."""


def get_db() -> Iterator[Session]:
    """FastAPI dependency that yields a transactional session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create tables if they don't exist. Called at app startup."""
    # Importing here avoids a circular import at module load.
    from . import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
