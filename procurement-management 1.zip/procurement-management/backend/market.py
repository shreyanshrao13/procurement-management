"""Market-data reader.

Parses ``market-data.js`` (the same file the frontend reads) so the
backend can use those indices as ``optional`` inputs to the should-cost
engine. Reuses the same regex approach as ``refresh_market_data.py`` so
the source of truth stays a single hand-edited JS file.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from . import config


def _strip_js(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    text = re.sub(r"//[^\n]*", "", text)
    return text


def load_market(path: Path | None = None) -> dict[str, Any]:
    """Return the parsed ``window.PM_DATA`` object as a Python dict.

    Returns an empty market dict if the file is missing — the engine is
    designed to run with or without market data.
    """
    p = Path(path or config.MARKET_DATA_FILE)
    if not p.is_file():
        return {"updated": None, "market": {}}

    raw = _strip_js(p.read_text(encoding="utf-8"))
    m = re.search(r"window\.PM_DATA\s*=\s*(\{.*\})\s*;?\s*$", raw, flags=re.DOTALL)
    if not m:
        return {"updated": None, "market": {}}
    obj = m.group(1)
    obj = re.sub(r'([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:', r'\1"\2":', obj)
    obj = re.sub(r",\s*([}\]])", r"\1", obj)
    return json.loads(obj)


def market_multiplier(linked_indices: list[str], scenario: dict[str, float] | None = None) -> tuple[float, list[dict[str, Any]]]:
    """Compute ``value/base - 1`` averaged across the linked indices,
    plus an optional user scenario shift (in percent).

    Returns ``(multiplier, per_index_detail)`` where multiplier is a
    fraction (0.05 == +5%) you add to 1.0.
    """
    pm = load_market().get("market", {})
    if not linked_indices:
        return 0.0, []

    detail: list[dict[str, Any]] = []
    deltas: list[float] = []
    for idx in linked_indices:
        m = pm.get(idx)
        if not m:
            continue
        base = m.get("base") or m.get("value") or 1.0
        value = m.get("value") or base
        live = (value / base) - 1.0
        scen = (scenario or {}).get(idx, 0.0) / 100.0
        total = live + scen
        deltas.append(total)
        detail.append({
            "id": idx,
            "label": m.get("label", idx),
            "value": value,
            "base": base,
            "live_delta_pct": live * 100,
            "scenario_pct": scen * 100,
            "applied_pct": total * 100,
        })

    if not deltas:
        return 0.0, detail
    return sum(deltas) / len(deltas), detail
