"""The should-cost engine — hybrid rule-based + ML.

Design
======

A single ``estimate(...)`` call returns:

    rule_unit_cost      always present; the explainable bottom-up build
    ml_unit_cost        only when enough historical POs exist
    hybrid_unit_cost    the headline number (weighted blend)
    breakdown           materials / labor / overhead / freight / margin
    drivers             ranked sensitivity list for the UI tornado
    explanations        plain-English notes for the negotiation brief

The blend weight depends on how much historical data the user has:

    rows < ML_MIN_ROWS              -> 100% rule
    ML_MIN_ROWS <= rows < FULL      -> linear ramp from 0 -> 0.6
    rows >= ML_FULL_TRUST_ROWS      -> 0.7 * ml + 0.3 * rule  (cap at 0.7)

ML is *never* allowed to be the sole authority — procurement teams need
a defensible cost build to take into a negotiation, and gradient
boosting on a few hundred POs cannot deliver that on its own.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy.orm import Session

from . import config, models
from .market import load_market, market_multiplier


# ---------- Cost-mix data class ----------------------------------------
@dataclass
class CostBreakdown:
    materials: float = 0.0
    labor: float = 0.0
    overhead: float = 0.0
    freight: float = 0.0
    margin: float = 0.0

    @property
    def total(self) -> float:
        return self.materials + self.labor + self.overhead + self.freight + self.margin

    def as_dict(self) -> dict[str, float]:
        d = self.__dict__.copy()
        d["total"] = self.total
        return d


@dataclass
class EstimateResult:
    method_used: str
    rule_unit_cost: float
    ml_unit_cost: float | None
    ml_confidence: float | None
    hybrid_unit_cost: float
    breakdown: CostBreakdown
    historical_avg: float | None
    market_reference: float | None
    market_multiplier: float
    drivers: list[dict[str, Any]] = field(default_factory=list)
    explanations: list[str] = field(default_factory=list)
    band_low: float = 0.0
    band_high: float = 0.0


# =====================================================================
# RULE-BASED PATH
# =====================================================================
def _latest_material_prices(db: Session) -> dict[str, float]:
    """Most recent ``MaterialPrice`` row per material, keyed by name."""
    rows = (
        db.query(models.MaterialPrice)
        .order_by(models.MaterialPrice.material, models.MaterialPrice.as_of.desc())
        .all()
    )
    out: dict[str, float] = {}
    for r in rows:
        out.setdefault(r.material, r.price)
    return out


def _market_index_unit_price(market_id: str) -> float | None:
    """Pull a price from market-data.js for a given index id (best-effort)."""
    pm = load_market().get("market", {})
    m = pm.get(market_id)
    if not m:
        return None
    return float(m.get("value", 0))


def rule_based(
    db: Session,
    cat: models.Category,
    quantity: float,
    market_scenario: dict[str, float] | None = None,
) -> tuple[CostBreakdown, list[dict[str, Any]], list[str]]:
    """Bottom-up build: BOM × material price + labor + overhead + freight + margin."""
    explanations: list[str] = []
    drivers: list[dict[str, Any]] = []

    # ---- Materials -----------------------------------------------------
    user_prices = _latest_material_prices(db)
    materials = 0.0
    by_material: list[tuple[str, float]] = []
    for item in cat.bom_items:
        # Price priority: user-uploaded -> linked market index -> 0 (warning)
        unit_price = user_prices.get(item.material)
        src = "user-uploaded price"
        if unit_price is None and item.market_index:
            unit_price = _market_index_unit_price(item.market_index)
            src = f"market index '{item.market_index}'"
        if unit_price is None:
            explanations.append(
                f"⚠ no price found for material '{item.material}' — set it in the materials sheet"
            )
            unit_price = 0.0
        cost = item.qty_per_unit * unit_price / max(item.yield_pct or 1.0, 0.01)
        materials += cost
        by_material.append((item.material, cost))
        if cost > 0:
            explanations.append(
                f"{item.material}: {item.qty_per_unit:g} {item.uom} × {unit_price:,.2f} ({src}) = {cost:,.2f}"
            )

    # ---- Labor ---------------------------------------------------------
    labor = 0.0
    for li in cat.labor_inputs:
        labor += li.hours_per_unit * li.rate_per_hour
        explanations.append(
            f"labor [{li.operation}]: {li.hours_per_unit:g}h × {li.rate_per_hour:,.2f}/h = "
            f"{li.hours_per_unit * li.rate_per_hour:,.2f}"
        )

    direct = materials + labor

    # ---- Fallbacks when BOM/labor sheets are empty ---------------------
    if direct <= 0:
        # Reverse-engineer from quotes / POs using the cost-mix percentages.
        anchor = _anchor_unit_cost(db, cat)
        if anchor:
            materials = anchor * cat.mix_materials
            labor = anchor * cat.mix_labor
            direct = materials + labor
            explanations.append(
                f"no BOM uploaded — anchored on observed unit cost {anchor:,.2f} "
                f"and split by category mix ({cat.mix_materials:.0%}/{cat.mix_labor:.0%})"
            )

    overhead = direct * cat.overhead_rate
    freight = direct * cat.freight_pct
    subtotal = direct + overhead + freight
    margin = subtotal * cat.target_margin

    # ---- Apply market scenario multiplier -----------------------------
    links = [s.strip() for s in (cat.market_links or "").split(",") if s.strip()]
    mkt_mult, mkt_detail = market_multiplier(links, market_scenario)
    if mkt_mult:
        # Apply only to materials + freight (the index-linked components).
        materials *= 1 + mkt_mult
        freight *= 1 + mkt_mult
        explanations.append(f"market multiplier on materials+freight: {mkt_mult * 100:+.1f}%")

    bd = CostBreakdown(
        materials=materials, labor=labor, overhead=overhead, freight=freight, margin=margin
    )

    # ---- Drivers (sensitivity tornado) --------------------------------
    total = bd.total or 1.0
    raw_drivers = [
        ("Materials / commodities", bd.materials, True if links else False, links),
        ("Labor", bd.labor, False, []),
        ("Overhead", bd.overhead, True, []),
        ("Freight & logistics", bd.freight, True, ["dryvan", "diesel"]),
        ("Supplier margin", bd.margin, True, []),
    ]
    raw_drivers.sort(key=lambda r: r[1], reverse=True)
    for name, val, lever, lk in raw_drivers:
        if val <= 0:
            continue
        share = val / total
        drivers.append(
            {
                "name": name,
                "share": share,
                "share_pct": share * 100,
                "influenceable": lever,
                "linked_indices": lk,
                "value_per_unit": val,
            }
        )

    if mkt_detail:
        explanations.append(
            "market exposure: "
            + ", ".join(f"{d['label']} {d['applied_pct']:+.1f}%" for d in mkt_detail)
        )

    return bd, drivers, explanations


def _anchor_unit_cost(db: Session, cat: models.Category) -> float | None:
    """Median observed unit price across POs + quotes — used as the
    fallback anchor when the user hasn't uploaded a BOM yet."""
    prices: list[float] = [p.unit_price for p in cat.purchase_orders]
    prices += [q.quoted_unit_price for q in cat.quotes]
    if not prices:
        return None
    return float(np.median(prices))


# =====================================================================
# ML PATH (scikit-learn, only when there's enough data)
# =====================================================================
def _po_features(rows: list[models.PurchaseOrder]) -> tuple[pd.DataFrame, pd.Series]:
    """Turn POs into a feature matrix for the regressor."""
    records = []
    for r in rows:
        rec = {
            "supplier": r.supplier or "unknown",
            "region": r.region or "GLOBAL",
            "quantity": r.quantity,
            "log_qty": math.log(max(r.quantity, 1.0)),
            "month": r.po_date.month if r.po_date else 1,
            "year": r.po_date.year if r.po_date else 2026,
            "y": r.unit_price,
        }
        # Spread out user-supplied spec fields.
        for k, v in (r.spec or {}).items():
            if isinstance(v, (int, float)):
                rec[f"spec_{k}"] = float(v)
            else:
                rec[f"spec_{k}"] = str(v)
        records.append(rec)
    df = pd.DataFrame.from_records(records)
    y = df.pop("y")
    return df, y


def ml_predict(
    cat: models.Category,
    quantity: float,
    region: str | None,
) -> tuple[float | None, float | None]:
    """Train (every call — cheap on small data, no caching needed yet) and
    predict the unit cost. Returns ``(prediction, confidence)``.

    Confidence here is the OOB R^2 of the random forest on the training
    set. Anything below 0.2 we treat as 'don't trust it'.
    """
    rows = list(cat.purchase_orders)
    if len(rows) < config.ML_MIN_ROWS:
        return None, None

    # Lazy import — keeps backend startup fast and lets unit tests run
    # without scikit-learn installed if they don't touch the ML path.
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder

    X, y = _po_features(rows)
    cat_cols = [c for c in X.columns if X[c].dtype == "object"]
    num_cols = [c for c in X.columns if c not in cat_cols]

    pre = ColumnTransformer(
        [("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols)],
        remainder="passthrough",
    )
    pipe = Pipeline(
        [
            ("pre", pre),
            (
                "rf",
                RandomForestRegressor(
                    n_estimators=200,
                    min_samples_leaf=2,
                    oob_score=True,
                    n_jobs=-1,
                    random_state=42,
                ),
            ),
        ]
    )
    pipe.fit(X, y)
    confidence = float(getattr(pipe.named_steps["rf"], "oob_score_", 0.0))

    # Build a feature row that matches what the user is asking about.
    template = X.iloc[0].copy()
    template["quantity"] = quantity
    template["log_qty"] = math.log(max(quantity, 1.0))
    if region:
        template["region"] = region
    pred = float(pipe.predict(pd.DataFrame([template]))[0])
    return pred, confidence


# =====================================================================
# HYBRID
# =====================================================================
def _ml_weight(n_rows: int, confidence: float | None) -> float:
    """Linear ramp from 0 to 0.7 as data grows, scaled by ML confidence.

    Procurement teams shouldn't blindly trust an ML number, so we cap the
    ML weight at 70% even with thousands of POs — the rule-based build
    always retains at least 30% influence over the headline number.
    """
    if n_rows < config.ML_MIN_ROWS or confidence is None or confidence < 0.2:
        return 0.0
    if n_rows >= config.ML_FULL_TRUST_ROWS:
        ramp = 0.7
    else:
        ramp = 0.7 * (n_rows - config.ML_MIN_ROWS) / max(
            config.ML_FULL_TRUST_ROWS - config.ML_MIN_ROWS, 1
        )
    return ramp * max(0.0, min(confidence, 1.0))


# =====================================================================
# Public entry point
# =====================================================================
def estimate(
    db: Session,
    cat: models.Category,
    quantity: float = 1.0,
    region: str | None = None,
    method: str = "auto",
    market_scenario: dict[str, float] | None = None,
) -> EstimateResult:
    """Run the engine and return a fully-populated result."""
    # ---- Rule-based (always) ------------------------------------------
    bd, drivers, explanations = rule_based(db, cat, quantity, market_scenario)
    rule_total = bd.total or 0.0

    # ---- ML (when method allows + data permits) -----------------------
    ml_pred: float | None = None
    ml_conf: float | None = None
    if method in ("auto", "ml", "hybrid"):
        try:
            ml_pred, ml_conf = ml_predict(cat, quantity, region)
        except Exception as exc:  # ML must never crash the request
            explanations.append(f"ml_path skipped: {exc.__class__.__name__}")

    # ---- Hybrid blend --------------------------------------------------
    n_pos = len(cat.purchase_orders)
    if method == "rule" or ml_pred is None:
        hybrid = rule_total
        method_used = "rule"
        explanations.append("method: rule-based bottom-up build")
    elif method == "ml":
        hybrid = ml_pred or rule_total
        method_used = "ml"
        explanations.append(
            f"method: ML on {n_pos} historical PO rows (OOB R²={ml_conf:.2f})"
        )
    else:  # auto / hybrid
        w = _ml_weight(n_pos, ml_conf)
        if w <= 0:
            hybrid = rule_total
            method_used = "rule"
            explanations.append(
                f"method: rule-based (only {n_pos} PO rows or ML confidence too low)"
            )
        else:
            hybrid = w * (ml_pred or rule_total) + (1 - w) * rule_total
            method_used = "hybrid"
            explanations.append(
                f"method: hybrid — {(1 - w):.0%} rule + {w:.0%} ML "
                f"({n_pos} POs, OOB R²={ml_conf:.2f})"
            )

    # ---- Historical & market reference --------------------------------
    historical_avg = _historical_average(cat)
    market_ref = _market_reference(cat)

    # ---- Band (low / high) --------------------------------------------
    band_low, band_high = _band(cat, hybrid)

    # ---- Persist run for audit ----------------------------------------
    run = models.ShouldCostRun(
        category_id=cat.id,
        method=method_used,
        quantity=quantity,
        region=region or cat.region,
        inputs={"market_scenario": market_scenario or {}},
        outputs={
            "rule": rule_total,
            "ml": ml_pred,
            "hybrid": hybrid,
            "breakdown": bd.as_dict(),
        },
    )
    db.add(run)
    db.commit()

    links = [s.strip() for s in (cat.market_links or "").split(",") if s.strip()]
    mkt_mult, _ = market_multiplier(links, market_scenario)

    return EstimateResult(
        method_used=method_used,
        rule_unit_cost=rule_total,
        ml_unit_cost=ml_pred,
        ml_confidence=ml_conf,
        hybrid_unit_cost=hybrid,
        breakdown=bd,
        historical_avg=historical_avg,
        market_reference=market_ref,
        market_multiplier=mkt_mult,
        drivers=drivers,
        explanations=explanations,
        band_low=band_low,
        band_high=band_high,
    )


def _historical_average(cat: models.Category) -> float | None:
    """Volume-weighted average unit price across the category's POs."""
    rows = cat.purchase_orders
    if not rows:
        return None
    qty = sum(r.quantity for r in rows) or 1.0
    return sum(r.unit_price * r.quantity for r in rows) / qty


def _market_reference(cat: models.Category) -> float | None:
    """Most-relevant single market index level (the first link)."""
    links = [s.strip() for s in (cat.market_links or "").split(",") if s.strip()]
    if not links:
        return None
    return _market_index_unit_price(links[0])


def _band(cat: models.Category, anchor: float) -> tuple[float, float]:
    """Low/high band: PO percentiles when we have data, ±20% otherwise."""
    prices = [p.unit_price for p in cat.purchase_orders]
    if len(prices) >= 5:
        return (
            float(np.quantile(prices, config.BAND_LOW_PCT)),
            float(np.quantile(prices, config.BAND_HIGH_PCT)),
        )
    return anchor * 0.8, anchor * 1.2
