"""Benchmarking + Negotiation Brief.

Inputs: a category and (optionally) a supplier quote. Outputs:

* a four-row comparison table (should-cost / quote / historical avg / market ref),
* anchor / target / walk-away prices,
* leverage points and concessions for the brief,
* a plain-text version of the brief suitable for paste-into-email.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from . import models
from .engine import EstimateResult, estimate
from .market import load_market


# ---------- Benchmark ---------------------------------------------------
def benchmark(
    db: Session,
    cat: models.Category,
    quantity: float,
    quote: float | None,
    region: str | None = None,
    market_scenario: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Compute the gap analysis vs. should-cost / history / market."""
    est: EstimateResult = estimate(
        db, cat, quantity=quantity, region=region, market_scenario=market_scenario
    )

    target = est.hybrid_unit_cost
    rows: list[dict[str, Any]] = []

    def _row(label: str, value: float | None, color: str) -> None:
        if value is None or value <= 0:
            return
        delta = ((value - target) / target * 100) if target else None
        rows.append(
            {
                "label": label,
                "unit_price": value,
                "annual": value * quantity,
                "delta_pct": delta,
                "color": color,
            }
        )

    _row("Should-cost (target)", target, "var(--green)")
    if quote and quote > 0:
        _row("Supplier quote", quote, "var(--rose)")
    _row("Historical average", est.historical_avg, "var(--mute)")
    # Note: ``est.market_reference`` is the raw market-index level
    # (e.g. $1105/short ton for steel HRC). It is NOT a per-unit price
    # for the finished good, so we expose it separately under
    # ``market_index_value`` rather than mixing it into this comparison.

    # Aggressive anchor = lower band; walk-away = upper band.
    anchor = est.band_low
    walk = est.band_high
    savings = max(0.0, (quote or target) - target) * quantity
    savings_pct = (
        ((quote - target) / quote * 100) if (quote and quote > 0 and target) else 0.0
    )

    if quote and quote > 0:
        if quote <= target * 1.03:
            verdict = "competitive"
            verdict_msg = "Quote is at or below should-cost — lock the rate and seek value-adds."
        elif quote <= walk:
            verdict = "headroom"
            verdict_msg = (
                f"Quote is +{((quote - target)/target * 100):.1f}% above should-cost but inside "
                f"the market band — solid case for {savings:,.0f} {cat.currency}/yr of headroom."
            )
        else:
            verdict = "out-of-band"
            verdict_msg = (
                f"Quote is +{((quote - target)/target * 100):.1f}% above should-cost AND above "
                f"the market band — strong case to push back."
            )
    else:
        verdict = "no-quote"
        verdict_msg = "Enter a supplier quote to generate the gap analysis."

    return {
        "category_id": cat.id,
        "rows": rows,
        "target": target,
        "aggressive_anchor": anchor,
        "walk_away": walk,
        "annual_savings": savings,
        "savings_pct": savings_pct,
        "verdict": verdict,
        "verdict_msg": verdict_msg,
        "market_index_value": est.market_reference,
        "market_multiplier": est.market_multiplier,
        "estimate": {
            "rule": est.rule_unit_cost,
            "ml": est.ml_unit_cost,
            "ml_confidence": est.ml_confidence,
            "hybrid": est.hybrid_unit_cost,
            "method_used": est.method_used,
            "breakdown": est.breakdown.as_dict(),
            "drivers": est.drivers,
            "explanations": est.explanations,
            "market_multiplier": est.market_multiplier,
        },
    }


# ---------- Negotiation Brief ------------------------------------------
def _market_context_lines(cat: models.Category) -> list[str]:
    """One bullet per linked market index, with current move + a play."""
    pm = load_market().get("market", {})
    links = [s.strip() for s in (cat.market_links or "").split(",") if s.strip()]
    out: list[str] = []
    for idx in links:
        m = pm.get(idx)
        if not m:
            continue
        mom = float(m.get("mom") or 0.0)
        direction = "rising" if mom > 0.5 else "easing" if mom < -0.5 else "stable"
        if mom > 0.5:
            play = "expect upward pressure — push for index caps and lock current pricing"
        elif mom < -0.5:
            play = "prices easing — demand the reduction be passed through"
        else:
            play = "stable — favourable window to fix price"
        out.append(
            f"{m.get('label', idx)} {m.get('value')} {m.get('unit', '')} "
            f"({mom:+.1f}% MoM, {direction}) — {play}"
        )
    if not out:
        out.append(
            "Low traded-commodity exposure — leverage lives in margin transparency, scope and volume."
        )
    return out


def negotiation_brief(
    db: Session,
    cat: models.Category,
    quantity: float,
    quote: float | None,
    region: str | None = None,
    market_scenario: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Assemble a one-page brief. Frontend renders it; engine ships data."""
    bench = benchmark(db, cat, quantity, quote, region, market_scenario)
    target = bench["target"]
    anchor = bench["aggressive_anchor"]
    walk = bench["walk_away"]

    drivers = bench["estimate"]["drivers"]
    levers = [d for d in drivers if d.get("influenceable")][:4]
    if not levers:
        levers = drivers[:3]

    leverage_points = []
    for d in levers:
        leverage_points.append(
            f"{d['name']} ({d['share_pct']:.0f}% of cost)"
            + (
                f" — exposed to {', '.join(d['linked_indices'])}"
                if d.get("linked_indices")
                else ""
            )
        )

    concessions = [
        f"Volume / spend commitment — consolidate {quantity:,.0f} {cat.unit.replace('per ', '')}/yr "
        "into one award for a tiered discount.",
        "Longer contract term (2–3 years) for a lower unit rate and a price-hold/index cap.",
        "Faster payment terms in exchange for a price concession.",
        "Reference customer / case study in return for best-in-class pricing.",
    ]

    market_context = _market_context_lines(cat)

    text = _brief_as_text(
        cat=cat,
        quantity=quantity,
        anchor=anchor,
        target=target,
        walk=walk,
        quote=quote,
        savings=bench["annual_savings"],
        savings_pct=bench["savings_pct"],
        leverage_points=leverage_points,
        market_context=market_context,
        concessions=concessions,
        explanations=bench["estimate"]["explanations"],
    )

    return {
        "category": cat.name,
        "family": cat.family,
        "quantity": quantity,
        "unit": cat.unit,
        "currency": cat.currency,
        "target_price": target,
        "aggressive_anchor": anchor,
        "walk_away": walk,
        "quote": quote,
        "annual_savings": bench["annual_savings"],
        "savings_pct": bench["savings_pct"],
        "verdict": bench["verdict"],
        "verdict_msg": bench["verdict_msg"],
        "leverage_points": leverage_points,
        "market_context": market_context,
        "concessions": concessions,
        "breakdown": bench["estimate"]["breakdown"],
        "explanations": bench["estimate"]["explanations"],
        "method_used": bench["estimate"]["method_used"],
        "ml_confidence": bench["estimate"]["ml_confidence"],
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "text": text,
    }


def _brief_as_text(
    cat: models.Category,
    quantity: float,
    anchor: float,
    target: float,
    walk: float,
    quote: float | None,
    savings: float,
    savings_pct: float,
    leverage_points: list[str],
    market_context: list[str],
    concessions: list[str],
    explanations: list[str],
) -> str:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    quote_line = (
        f"Supplier quote: {quote:,.2f} {cat.currency} ({quote * quantity:,.0f}/yr)\n"
        if quote and quote > 0
        else "Supplier quote: (none entered)\n"
    )
    return (
        f"NEGOTIATION BRIEF — {cat.name}\n"
        f"{today}\n\n"
        f"Volume: {quantity:,.0f} {cat.unit}/yr | Currency: {cat.currency}\n"
        f"{quote_line}\n"
        f"PRICE POSITIONS (per unit)\n"
        f"- Opening anchor (aggressive): {anchor:,.2f}\n"
        f"- Target (should-cost):       {target:,.2f}\n"
        f"- Walk-away (do not exceed):  {walk:,.2f}\n\n"
        f"SAVINGS: {savings:,.0f} {cat.currency}/yr ({savings_pct:.1f}% of quoted spend)\n\n"
        f"LEVERAGE POINTS\n"
        + "\n".join(f"- {x}" for x in leverage_points)
        + "\n\nMARKET CONTEXT\n"
        + "\n".join(f"- {x}" for x in market_context)
        + "\n\nCONCESSIONS\n"
        + "\n".join(f"- {x}" for x in concessions)
        + "\n\nMETHOD & DATA\n"
        + "\n".join(f"- {x}" for x in explanations)
        + "\n\nGenerated by ProcureMind Should-Cost Platform.\n"
    )
