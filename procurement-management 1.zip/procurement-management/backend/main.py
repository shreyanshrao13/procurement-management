"""FastAPI application — the public surface of the platform.

Endpoints (grouped):

    /api/health                                  liveness probe + version
    /api/market                                  read market-data.js as JSON

    /api/categories                              CRUD over categories
    /api/categories/{id}/bom                     replace/get BOM
    /api/categories/{id}/labor                   replace/get labor inputs
    /api/categories/{id}/quotes                  add/list supplier quotes
    /api/categories/{id}/pos                     add/list historical POs

    /api/upload/categories | bom | labor |
                materials | purchase_orders |
                quotes                           file uploads (CSV/XLSX)

    /api/should-cost                             POST: run the engine
    /api/benchmark                               POST: gap analysis
    /api/brief                                   POST: negotiation brief

    /                                            serves index.html
    /api/docs                                    Swagger UI
"""

from __future__ import annotations

import io
from datetime import datetime, timezone
from pathlib import Path

from fastapi import (
    Depends,
    FastAPI,
    File,
    HTTPException,
    UploadFile,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from . import benchmark as bench_mod
from . import config, engine, ingest, models, schemas
from .db import get_db, init_db
from .market import load_market

# ---------------------------------------------------------------------------
app = FastAPI(
    title="ProcureMind — Should-Cost Intelligence Platform",
    version="1.0.0",
    description=(
        "Hybrid (rule-based + ML) should-cost estimation engine. Upload your "
        "company's BOM, labor, historical POs and supplier quotes to get a "
        "dynamic, defensible target price for any procurement category."
    ),
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # local-first; restrict for prod
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup() -> None:
    init_db()


# =====================================================================
# Health + market data
# =====================================================================
@app.get("/api/health")
def health() -> dict:
    return {
        "status": "ok",
        "version": "1.0.0",
        "db": str(config.DB_PATH),
        "time": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/market")
def market() -> dict:
    return load_market()


# =====================================================================
# Categories (CRUD)
# =====================================================================
def _summary(c: models.Category) -> schemas.CategorySummary:
    return schemas.CategorySummary(
        id=c.id, code=c.code, name=c.name, family=c.family,
        unit=c.unit, region=c.region, currency=c.currency,
        n_bom_items=len(c.bom_items),
        n_pos=len(c.purchase_orders),
        n_quotes=len(c.quotes),
    )


def _full(c: models.Category) -> schemas.CategoryOut:
    return schemas.CategoryOut(
        id=c.id, code=c.code, name=c.name, family=c.family,
        unit=c.unit, region=c.region, currency=c.currency,
        mix_materials=c.mix_materials, mix_labor=c.mix_labor,
        mix_overhead=c.mix_overhead, mix_margin=c.mix_margin,
        overhead_rate=c.overhead_rate, target_margin=c.target_margin,
        freight_pct=c.freight_pct, notes=c.notes,
        market_links=c.market_links,
        created_at=c.created_at, updated_at=c.updated_at,
        n_bom_items=len(c.bom_items),
        n_pos=len(c.purchase_orders),
        n_quotes=len(c.quotes),
    )


@app.get("/api/categories", response_model=list[schemas.CategorySummary])
def list_categories(db: Session = Depends(get_db)):
    return [_summary(c) for c in db.query(models.Category).all()]


@app.post("/api/categories", response_model=schemas.CategoryOut, status_code=status.HTTP_201_CREATED)
def create_category(payload: schemas.CategoryIn, db: Session = Depends(get_db)):
    if db.query(models.Category).filter_by(code=payload.code).first():
        raise HTTPException(409, f"category code '{payload.code}' already exists")
    c = models.Category(**payload.model_dump())
    db.add(c)
    db.commit()
    db.refresh(c)
    return _full(c)


@app.get("/api/categories/{cat_id}", response_model=schemas.CategoryOut)
def get_category(cat_id: int, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    return _full(c)


@app.put("/api/categories/{cat_id}", response_model=schemas.CategoryOut)
def update_category(cat_id: int, payload: schemas.CategoryIn, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    for k, v in payload.model_dump().items():
        setattr(c, k, v)
    db.commit()
    db.refresh(c)
    return _full(c)


@app.delete("/api/categories/{cat_id}", status_code=204)
def delete_category(cat_id: int, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    db.delete(c)
    db.commit()


# ---- BOM / Labor / POs / Quotes (per category) ----
@app.get("/api/categories/{cat_id}/bom", response_model=list[schemas.BomItemOut])
def list_bom(cat_id: int, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    return list(c.bom_items)


@app.put("/api/categories/{cat_id}/bom", response_model=list[schemas.BomItemOut])
def replace_bom(cat_id: int, items: list[schemas.BomItemIn], db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    # Replace wholesale — easier mental model than diff.
    for old in list(c.bom_items):
        db.delete(old)
    for it in items:
        db.add(models.BomItem(category_id=cat_id, **it.model_dump()))
    db.commit()
    db.refresh(c)
    return list(c.bom_items)


@app.get("/api/categories/{cat_id}/labor", response_model=list[schemas.LaborInputOut])
def list_labor(cat_id: int, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    return list(c.labor_inputs)


@app.put("/api/categories/{cat_id}/labor", response_model=list[schemas.LaborInputOut])
def replace_labor(cat_id: int, items: list[schemas.LaborInputIn], db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    for old in list(c.labor_inputs):
        db.delete(old)
    for it in items:
        db.add(models.LaborInput(category_id=cat_id, **it.model_dump()))
    db.commit()
    db.refresh(c)
    return list(c.labor_inputs)


@app.post("/api/categories/{cat_id}/quotes")
def add_quote(cat_id: int, q: schemas.SupplierQuoteIn, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    row = models.SupplierQuote(category_id=cat_id, **q.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"id": row.id}


@app.get("/api/categories/{cat_id}/quotes")
def list_quotes(cat_id: int, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    return [
        {
            "id": q.id, "supplier": q.supplier, "quoted_unit_price": q.quoted_unit_price,
            "quantity": q.quantity, "currency": q.currency,
            "valid_until": q.valid_until.isoformat() if q.valid_until else None,
            "received_at": q.received_at.isoformat(), "notes": q.notes,
        }
        for q in c.quotes
    ]


@app.post("/api/categories/{cat_id}/pos")
def add_po(cat_id: int, p: schemas.PurchaseOrderIn, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    payload = p.model_dump()
    if payload.get("po_date") is None:
        payload["po_date"] = datetime.now(timezone.utc)
    row = models.PurchaseOrder(category_id=cat_id, **payload)
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"id": row.id}


@app.get("/api/categories/{cat_id}/pos")
def list_pos(cat_id: int, db: Session = Depends(get_db)):
    c = db.get(models.Category, cat_id)
    if not c:
        raise HTTPException(404)
    return [
        {
            "id": p.id, "supplier": p.supplier,
            "po_date": p.po_date.isoformat() if p.po_date else None,
            "quantity": p.quantity, "unit_price": p.unit_price,
            "region": p.region, "currency": p.currency, "spec": p.spec,
        }
        for p in c.purchase_orders
    ]


# =====================================================================
# Bulk uploads
# =====================================================================
async def _read_upload(f: UploadFile) -> bytes:
    body = await f.read()
    if len(body) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"file too large (>{config.MAX_UPLOAD_MB}MB)")
    return body


def _ensure_category(db: Session, code: str) -> models.Category:
    c = db.query(models.Category).filter_by(code=code).first()
    if c:
        return c
    c = models.Category(code=code, name=code)
    db.add(c)
    db.flush()
    return c


@app.post("/api/upload/categories", response_model=schemas.UploadResult)
async def upload_categories(file: UploadFile = File(...), db: Session = Depends(get_db)):
    body = await _read_upload(file)
    df = ingest.load("categories", body, filename=file.filename or "")
    rows = 0
    touched = 0
    for r in ingest.to_records(df):
        c = db.query(models.Category).filter_by(code=r["code"]).first()
        if c is None:
            c = models.Category(code=r["code"], name=r["name"])
            db.add(c)
            touched += 1
        for k in (
            "name", "family", "unit", "region", "currency",
            "notes", "market_links",
        ):
            if k in r and r.get(k) not in (None, ""):
                setattr(c, k, r[k])
        rows += 1
    db.commit()
    return schemas.UploadResult(
        filename=file.filename or "", rows_read=len(df), rows_inserted=rows,
        categories_touched=touched, warnings=[],
    )


@app.post("/api/upload/bom", response_model=schemas.UploadResult)
async def upload_bom(file: UploadFile = File(...), db: Session = Depends(get_db)):
    body = await _read_upload(file)
    df = ingest.load("bom", body, filename=file.filename or "")
    cat_codes = set()
    rows = 0
    for r in ingest.to_records(df):
        cat = _ensure_category(db, str(r["category_code"]))
        cat_codes.add(cat.code)
        db.add(models.BomItem(
            category_id=cat.id,
            material=str(r["material"]),
            qty_per_unit=float(r["qty_per_unit"]),
            uom=str(r.get("uom") or "kg"),
            yield_pct=float(r.get("yield_pct") or 1.0),
            market_index=str(r.get("market_index") or ""),
        ))
        rows += 1
    db.commit()
    return schemas.UploadResult(
        filename=file.filename or "", rows_read=len(df), rows_inserted=rows,
        categories_touched=len(cat_codes),
    )


@app.post("/api/upload/labor", response_model=schemas.UploadResult)
async def upload_labor(file: UploadFile = File(...), db: Session = Depends(get_db)):
    body = await _read_upload(file)
    df = ingest.load("labor", body, filename=file.filename or "")
    cat_codes = set()
    rows = 0
    for r in ingest.to_records(df):
        cat = _ensure_category(db, str(r["category_code"]))
        cat_codes.add(cat.code)
        db.add(models.LaborInput(
            category_id=cat.id,
            operation=str(r.get("operation") or "primary"),
            hours_per_unit=float(r["hours_per_unit"]),
            rate_per_hour=float(r["rate_per_hour"]),
            region=str(r.get("region") or "GLOBAL"),
        ))
        rows += 1
    db.commit()
    return schemas.UploadResult(
        filename=file.filename or "", rows_read=len(df), rows_inserted=rows,
        categories_touched=len(cat_codes),
    )


@app.post("/api/upload/materials", response_model=schemas.UploadResult)
async def upload_materials(file: UploadFile = File(...), db: Session = Depends(get_db)):
    body = await _read_upload(file)
    df = ingest.load("materials", body, filename=file.filename or "")
    rows = 0
    for r in ingest.to_records(df):
        as_of = r.get("as_of")
        as_of_dt = (
            as_of.to_pydatetime() if hasattr(as_of, "to_pydatetime") and as_of is not None
            else datetime.now(timezone.utc)
        )
        material = str(r["material"])
        source = str(r.get("source") or "user")
        existing = (
            db.query(models.MaterialPrice)
            .filter_by(material=material, as_of=as_of_dt, source=source)
            .first()
        )
        if existing is None:
            db.add(models.MaterialPrice(
                material=material,
                price=float(r["price"]),
                uom=str(r.get("uom") or "kg"),
                currency=str(r.get("currency") or "USD"),
                as_of=as_of_dt,
                source=source,
            ))
        else:
            existing.price = float(r["price"])
            existing.uom = str(r.get("uom") or existing.uom or "kg")
            existing.currency = str(r.get("currency") or existing.currency or "USD")
        rows += 1
    db.commit()
    return schemas.UploadResult(
        filename=file.filename or "", rows_read=len(df), rows_inserted=rows,
        categories_touched=0,
    )


@app.post("/api/upload/purchase_orders", response_model=schemas.UploadResult)
async def upload_pos(file: UploadFile = File(...), db: Session = Depends(get_db)):
    body = await _read_upload(file)
    df = ingest.load("purchase_orders", body, filename=file.filename or "")
    cat_codes = set()
    rows = 0
    extra_cols = [
        c for c in df.columns
        if c not in {"category_code", "supplier", "po_date", "quantity", "unit_price", "region", "currency"}
    ]
    for r in ingest.to_records(df):
        cat = _ensure_category(db, str(r["category_code"]))
        cat_codes.add(cat.code)
        po_date = r.get("po_date")
        po_dt = (
            po_date.to_pydatetime() if hasattr(po_date, "to_pydatetime") and po_date is not None
            else datetime.now(timezone.utc)
        )
        spec = {k: r[k] for k in extra_cols if r.get(k) is not None}
        db.add(models.PurchaseOrder(
            category_id=cat.id,
            supplier=str(r.get("supplier") or ""),
            po_date=po_dt,
            quantity=float(r["quantity"]),
            unit_price=float(r["unit_price"]),
            region=str(r.get("region") or "GLOBAL"),
            currency=str(r.get("currency") or "USD"),
            spec=spec,
        ))
        rows += 1
    db.commit()
    return schemas.UploadResult(
        filename=file.filename or "", rows_read=len(df), rows_inserted=rows,
        categories_touched=len(cat_codes),
    )


@app.post("/api/upload/quotes", response_model=schemas.UploadResult)
async def upload_quotes(file: UploadFile = File(...), db: Session = Depends(get_db)):
    body = await _read_upload(file)
    df = ingest.load("quotes", body, filename=file.filename or "")
    cat_codes = set()
    rows = 0
    for r in ingest.to_records(df):
        cat = _ensure_category(db, str(r["category_code"]))
        cat_codes.add(cat.code)
        valid_until = r.get("valid_until")
        valid_dt = (
            valid_until.to_pydatetime()
            if hasattr(valid_until, "to_pydatetime") and valid_until is not None
            else None
        )
        db.add(models.SupplierQuote(
            category_id=cat.id,
            supplier=str(r["supplier"]),
            quoted_unit_price=float(r["quoted_unit_price"]),
            quantity=float(r.get("quantity") or 1.0),
            currency=str(r.get("currency") or "USD"),
            valid_until=valid_dt,
            notes=str(r.get("notes") or ""),
        ))
        rows += 1
    db.commit()
    return schemas.UploadResult(
        filename=file.filename or "", rows_read=len(df), rows_inserted=rows,
        categories_touched=len(cat_codes),
    )



# =====================================================================
# Engine endpoints
# =====================================================================
@app.post("/api/should-cost")
def should_cost(req: schemas.EstimateRequest, db: Session = Depends(get_db)):
    cat = db.get(models.Category, req.category_id)
    if not cat:
        raise HTTPException(404, "category not found")

    res = engine.estimate(
        db,
        cat,
        quantity=req.quantity,
        region=req.region,
        method=req.method,
        market_scenario=req.market_scenario,
    )
    return {
        "category_id": cat.id,
        "category_name": cat.name,
        "currency": cat.currency,
        "unit": cat.unit,
        "quantity": req.quantity,
        "method_used": res.method_used,
        "rule_unit_cost": res.rule_unit_cost,
        "ml_unit_cost": res.ml_unit_cost,
        "ml_confidence": res.ml_confidence,
        "hybrid_unit_cost": res.hybrid_unit_cost,
        "breakdown": res.breakdown.as_dict(),
        "drivers": res.drivers,
        "explanations": res.explanations,
        "historical_avg": res.historical_avg,
        "market_reference": res.market_reference,
        "market_multiplier": res.market_multiplier,
        "band_low": res.band_low,
        "band_high": res.band_high,
    }


@app.post("/api/benchmark")
def benchmark_endpoint(req: schemas.EstimateRequest, db: Session = Depends(get_db)):
    cat = db.get(models.Category, req.category_id)
    if not cat:
        raise HTTPException(404, "category not found")
    return bench_mod.benchmark(
        db, cat,
        quantity=req.quantity,
        quote=req.quote,
        region=req.region,
        market_scenario=req.market_scenario,
    )


@app.post("/api/brief")
def brief_endpoint(req: schemas.EstimateRequest, db: Session = Depends(get_db)):
    cat = db.get(models.Category, req.category_id)
    if not cat:
        raise HTTPException(404, "category not found")
    return bench_mod.negotiation_brief(
        db, cat,
        quantity=req.quantity,
        quote=req.quote,
        region=req.region,
        market_scenario=req.market_scenario,
    )


# =====================================================================
# Static frontend (index.html, market-data.js, app.js)
# =====================================================================
@app.get("/")
def root() -> FileResponse:
    return FileResponse(str(config.FRONTEND_DIR / "index.html"))


# Mount the repo root as static so /index.html, /market-data.js, /app.js
# all just work. Order matters — this comes after all /api routes.
app.mount("/", StaticFiles(directory=str(config.FRONTEND_DIR), html=True), name="static")


# =====================================================================
# Convenience launcher
# =====================================================================
def run() -> None:
    """``python -m backend.main`` or ``procuremind`` entry-point."""
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=config.HOST,
        port=config.PORT,
        reload=False,
    )


if __name__ == "__main__":
    run()
