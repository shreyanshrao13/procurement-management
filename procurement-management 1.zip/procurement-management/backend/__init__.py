"""ProcureMind — Should-Cost Intelligence Platform backend."""

__version__ = "1.0.0"
