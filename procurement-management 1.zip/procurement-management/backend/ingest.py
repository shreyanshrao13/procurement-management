"""CSV / Excel ingestion.

The platform should accept the messy reality of procurement spreadsheets:
column names vary, casing is inconsistent, dates come in five formats.
This module canonicalises everything before it touches the database.

Each public ``load_*`` function:
1. accepts a file path or an in-memory bytes blob,
2. detects format by extension,
3. coerces column names via ``COLUMN_ALIASES``,
4. validates required columns and raises a helpful error,
5. returns a ``pandas.DataFrame`` with stable column names.

The DB writers (in ``main.py``) consume those frames row-by-row.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import IO

import pandas as pd

# Map "what the user wrote" -> "what we store".
# Lowercased, whitespace-stripped, punctuation collapsed to underscores.
COLUMN_ALIASES: dict[str, dict[str, str]] = {
    "categories": {
        "category_code": "code", "code": "code", "id": "code", "sku": "code",
        "category": "name", "name": "name", "description": "name",
        "family": "family", "group": "family",
        "unit": "unit", "uom": "unit",
        "region": "region", "country": "region",
        "currency": "currency", "ccy": "currency",
        "notes": "notes", "comment": "notes",
        "market_links": "market_links", "indices": "market_links",
    },
    "bom": {
        "category": "category_code", "category_code": "category_code",
        "sku": "category_code", "product": "category_code",
        "material": "material", "component": "material", "part": "material",
        "qty": "qty_per_unit", "qty_per_unit": "qty_per_unit",
        "quantity": "qty_per_unit", "quantity_per_unit": "qty_per_unit",
        "uom": "uom", "unit": "uom", "unit_of_measure": "uom",
        "yield": "yield_pct", "yield_pct": "yield_pct", "yield_percent": "yield_pct",
        "market_index": "market_index", "index": "market_index", "commodity": "market_index",
    },
    "labor": {
        "category": "category_code", "category_code": "category_code", "sku": "category_code",
        "operation": "operation", "step": "operation", "process": "operation",
        "hours": "hours_per_unit", "hours_per_unit": "hours_per_unit",
        "time": "hours_per_unit",
        "rate": "rate_per_hour", "rate_per_hour": "rate_per_hour",
        "wage": "rate_per_hour", "hourly_rate": "rate_per_hour",
        "region": "region", "country": "region",
    },
    "materials": {
        "material": "material", "name": "material", "commodity": "material",
        "price": "price", "unit_price": "price", "cost": "price",
        "uom": "uom", "unit": "uom",
        "currency": "currency", "ccy": "currency",
        "as_of": "as_of", "date": "as_of", "effective_date": "as_of",
        "source": "source",
    },
    "purchase_orders": {
        "category": "category_code", "category_code": "category_code", "sku": "category_code",
        "supplier": "supplier", "vendor": "supplier",
        "po_date": "po_date", "date": "po_date", "order_date": "po_date",
        "quantity": "quantity", "qty": "quantity", "volume": "quantity",
        "unit_price": "unit_price", "price": "unit_price", "cost": "unit_price",
        "region": "region", "country": "region",
        "currency": "currency", "ccy": "currency",
    },
    "quotes": {
        "category": "category_code", "category_code": "category_code", "sku": "category_code",
        "supplier": "supplier", "vendor": "supplier",
        "quoted_unit_price": "quoted_unit_price",
        "price": "quoted_unit_price", "unit_price": "quoted_unit_price",
        "quote": "quoted_unit_price",
        "quantity": "quantity", "qty": "quantity",
        "currency": "currency", "ccy": "currency",
        "valid_until": "valid_until", "expires": "valid_until", "expiry": "valid_until",
        "notes": "notes", "comment": "notes",
    },
}


REQUIRED: dict[str, list[str]] = {
    "categories": ["code", "name"],
    "bom": ["category_code", "material", "qty_per_unit"],
    "labor": ["category_code", "hours_per_unit", "rate_per_hour"],
    "materials": ["material", "price"],
    "purchase_orders": ["category_code", "quantity", "unit_price"],
    "quotes": ["category_code", "supplier", "quoted_unit_price"],
}


# ---------------------------------------------------------------------------


def _read_any(src: str | Path | bytes | IO[bytes], filename: str = "") -> pd.DataFrame:
    """Read a CSV or XLSX from a path / bytes / file-like into a DataFrame."""
    name = (filename or (str(src) if isinstance(src, (str, Path)) else "")).lower()
    is_excel = name.endswith((".xlsx", ".xls", ".xlsm"))

    if isinstance(src, bytes):
        buf = io.BytesIO(src)
        return pd.read_excel(buf) if is_excel else pd.read_csv(buf)
    if hasattr(src, "read"):
        return pd.read_excel(src) if is_excel else pd.read_csv(src)
    return pd.read_excel(src) if is_excel else pd.read_csv(src)


def _normalise_cols(df: pd.DataFrame, kind: str) -> pd.DataFrame:
    """Lowercase + alias-rename columns; keep unknown columns as-is."""
    aliases = COLUMN_ALIASES[kind]
    new_cols = {}
    for c in df.columns:
        key = str(c).strip().lower().replace(" ", "_").replace("-", "_")
        new_cols[c] = aliases.get(key, key)
    return df.rename(columns=new_cols)


def _validate(df: pd.DataFrame, kind: str) -> None:
    missing = [c for c in REQUIRED[kind] if c not in df.columns]
    if missing:
        raise ValueError(
            f"{kind}: missing required column(s) {missing}. "
            f"Found columns: {list(df.columns)}. "
            f"Recognised aliases: {sorted(set(COLUMN_ALIASES[kind].keys()))}"
        )


def load(kind: str, src: str | Path | bytes | IO[bytes], filename: str = "") -> pd.DataFrame:
    """Public entry point. ``kind`` is one of ``REQUIRED.keys()``."""
    if kind not in REQUIRED:
        raise ValueError(f"unknown ingest kind {kind!r}. expected one of {list(REQUIRED)}")

    df = _read_any(src, filename=filename)
    df = _normalise_cols(df, kind)
    _validate(df, kind)
    return _coerce_types(df, kind)


def to_records(df: pd.DataFrame) -> list[dict]:
    """``df.to_dict(orient="records")`` with NaN / NaT scrubbed to ``None``.

    Pandas surfaces empty CSV cells as ``float('nan')``, which is *truthy* —
    so ``r.get(col) or "default"`` silently returns NaN and corrupts the DB.
    This helper is the only sanctioned way to iterate ingested rows.
    """
    out: list[dict] = []
    for r in df.to_dict(orient="records"):
        clean: dict = {}
        for k, v in r.items():
            try:
                if pd.isna(v):
                    clean[k] = None
                    continue
            except (TypeError, ValueError):
                pass
            clean[k] = v
        out.append(clean)
    return out


def _coerce_types(df: pd.DataFrame, kind: str) -> pd.DataFrame:
    """Best-effort type coercion. Bad rows are dropped, not silently kept."""
    df = df.copy()

    numeric_cols = {
        "bom": ["qty_per_unit", "yield_pct"],
        "labor": ["hours_per_unit", "rate_per_hour"],
        "materials": ["price"],
        "purchase_orders": ["quantity", "unit_price"],
        "quotes": ["quoted_unit_price", "quantity"],
        "categories": [],
    }
    for c in numeric_cols.get(kind, []):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    date_cols = {
        "materials": ["as_of"],
        "purchase_orders": ["po_date"],
        "quotes": ["valid_until"],
    }
    for c in date_cols.get(kind, []):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce", utc=True)

    # Drop rows missing any required value (after coercion).
    before = len(df)
    df = df.dropna(subset=[c for c in REQUIRED[kind] if c in df.columns])
    df.attrs["dropped_rows"] = before - len(df)

    # Default fills.
    if kind == "bom" and "yield_pct" in df.columns:
        df["yield_pct"] = df["yield_pct"].fillna(1.0)
    if kind == "purchase_orders" and "po_date" in df.columns:
        df["po_date"] = df["po_date"].fillna(pd.Timestamp.now(tz="UTC"))

    return df.reset_index(drop=True)
