"""One-shot seeder: load every ``data/sample_*.csv`` into the database.

Usage
-----
    python -m backend.seed              # idempotent: skips existing
    python -m backend.seed --reset      # wipe and re-load (DESTRUCTIVE)
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

from . import config, ingest, models
from .db import SessionLocal, engine, init_db


SAMPLES = {
    "categories":      "sample_categories.csv",
    "materials":       "sample_materials.csv",
    "bom":             "sample_bom.csv",
    "labor":           "sample_labor.csv",
    "purchase_orders": "sample_purchase_orders.csv",
    "quotes":          "sample_quotes.csv",
}


def _ensure_category(db, code: str) -> models.Category:
    c = db.query(models.Category).filter_by(code=code).first()
    if c:
        return c
    c = models.Category(code=code, name=code)
    db.add(c)
    db.flush()
    return c


def seed(reset: bool = False) -> None:
    init_db()
    if reset:
        # Drop and recreate tables — destructive but local-only.
        models.Base.metadata.drop_all(bind=engine)
        models.Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        # ---- Categories ----------------------------------------------
        df = ingest.load("categories", config.DATA_DIR / SAMPLES["categories"])
        for r in ingest.to_records(df):
            c = db.query(models.Category).filter_by(code=r["code"]).first()
            if c is None:
                c = models.Category(code=r["code"], name=r["name"])
                db.add(c)
            for k in ("name", "family", "unit", "region", "currency", "notes", "market_links"):
                if r.get(k) not in (None, ""):
                    setattr(c, k, r[k])
        db.commit()

        # ---- Materials -----------------------------------------------
        df = ingest.load("materials", config.DATA_DIR / SAMPLES["materials"])
        if not reset:
            db.query(models.MaterialPrice).delete()
            db.commit()
        for r in ingest.to_records(df):
            as_of = r.get("as_of")
            as_of_dt = (
                as_of.to_pydatetime() if hasattr(as_of, "to_pydatetime") and as_of is not None
                else datetime.now(timezone.utc)
            )
            db.add(models.MaterialPrice(
                material=r["material"], price=float(r["price"]),
                uom=r.get("uom") or "kg", currency=r.get("currency") or "USD",
                as_of=as_of_dt, source=r.get("source") or "user",
            ))
        db.commit()

        # ---- BOM (replace per category) ------------------------------
        df = ingest.load("bom", config.DATA_DIR / SAMPLES["bom"])
        seen_cats = set()
        for r in ingest.to_records(df):
            cat = _ensure_category(db, str(r["category_code"]))
            if cat.id not in seen_cats and not reset:
                # On a fresh run, clear existing BOM for cleanliness.
                for old in list(cat.bom_items):
                    db.delete(old)
                seen_cats.add(cat.id)
            db.add(models.BomItem(
                category_id=cat.id, material=str(r["material"]),
                qty_per_unit=float(r["qty_per_unit"]),
                uom=r.get("uom") or "kg",
                yield_pct=float(r.get("yield_pct") or 1.0),
                market_index=r.get("market_index") or "",
            ))
        db.commit()

        # ---- Labor ----------------------------------------------------
        df = ingest.load("labor", config.DATA_DIR / SAMPLES["labor"])
        seen_cats = set()
        for r in ingest.to_records(df):
            cat = _ensure_category(db, str(r["category_code"]))
            if cat.id not in seen_cats and not reset:
                for old in list(cat.labor_inputs):
                    db.delete(old)
                seen_cats.add(cat.id)
            db.add(models.LaborInput(
                category_id=cat.id,
                operation=r.get("operation") or "primary",
                hours_per_unit=float(r["hours_per_unit"]),
                rate_per_hour=float(r["rate_per_hour"]),
                region=r.get("region") or "GLOBAL",
            ))
        db.commit()

        # ---- POs ------------------------------------------------------
        df = ingest.load("purchase_orders", config.DATA_DIR / SAMPLES["purchase_orders"])
        spec_cols = [c for c in df.columns if c not in {
            "category_code", "supplier", "po_date", "quantity",
            "unit_price", "region", "currency",
        }]
        seen_cats = set()
        for r in ingest.to_records(df):
            cat = _ensure_category(db, str(r["category_code"]))
            if cat.id not in seen_cats and not reset:
                for old in list(cat.purchase_orders):
                    db.delete(old)
                seen_cats.add(cat.id)
            po_date = r.get("po_date")
            po_dt = (
                po_date.to_pydatetime() if hasattr(po_date, "to_pydatetime") and po_date is not None
                else datetime.now(timezone.utc)
            )
            spec = {k: r[k] for k in spec_cols if r.get(k) is not None}
            db.add(models.PurchaseOrder(
                category_id=cat.id, supplier=r.get("supplier") or "",
                po_date=po_dt, quantity=float(r["quantity"]),
                unit_price=float(r["unit_price"]),
                region=r.get("region") or "GLOBAL",
                currency=r.get("currency") or "USD",
                spec=spec,
            ))
        db.commit()

        # ---- Quotes ---------------------------------------------------
        df = ingest.load("quotes", config.DATA_DIR / SAMPLES["quotes"])
        seen_cats = set()
        for r in ingest.to_records(df):
            cat = _ensure_category(db, str(r["category_code"]))
            if cat.id not in seen_cats and not reset:
                for old in list(cat.quotes):
                    db.delete(old)
                seen_cats.add(cat.id)
            valid_until = r.get("valid_until")
            valid_dt = valid_until.to_pydatetime() if hasattr(valid_until, "to_pydatetime") and valid_until is not None else None
            db.add(models.SupplierQuote(
                category_id=cat.id, supplier=r["supplier"],
                quoted_unit_price=float(r["quoted_unit_price"]),
                quantity=float(r.get("quantity") or 1.0),
                currency=r.get("currency") or "USD",
                valid_until=valid_dt, notes=r.get("notes") or "",
            ))
        db.commit()

        # ---- Summary --------------------------------------------------
        n_cats = db.query(models.Category).count()
        n_pos = db.query(models.PurchaseOrder).count()
        n_quotes = db.query(models.SupplierQuote).count()
        n_bom = db.query(models.BomItem).count()
        print(
            f"seeded: {n_cats} categories, {n_bom} BOM lines, "
            f"{n_pos} POs, {n_quotes} quotes."
        )
    finally:
        db.close()


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--reset", action="store_true",
                   help="DROP all tables before re-seeding. Destructive.")
    args = p.parse_args(argv)
    seed(reset=args.reset)
    return 0


if __name__ == "__main__":
    sys.exit(main())
